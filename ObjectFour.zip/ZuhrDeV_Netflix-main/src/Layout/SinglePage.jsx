import React from 'react'

function SinglePage() {
  return (
    <div className='px-4 pt-20 text-white'>
      <div className="container-singlePage">
      <h1 className="text-4xl font-bold text-gray-900">
          Single Page
        </h1>
        <p className="text-xl text-gray-500">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
        </p>
      </div>
    </div>
  )
}

export default SinglePage
