const cart_row = document.querySelector(".cart-row");

const array = localStorage.getItem("cart");
let selectedItems = JSON.parse(array) || [];

const remove = (_id) => {
  try {
    // Remove the item with the given _id from selectedItems
    selectedItems = selectedItems.filter(el => el._id != _id);

    // Save the updated selectedItems to localStorage
    localStorage.setItem("cart", JSON.stringify(selectedItems));

    // Reload the page
    location.reload();
  } catch (error) {
    console.error("An error occurred:", error);
  }
}

const productCount = (selectedItems) => selectedItems.length;

const productsSum = (selectedItems) => {
  let ProductsSum = 0;
  selectedItems.forEach((el) => {
    ProductsSum += el.price * el.quantity;
  });
  return Math.floor(ProductsSum);
};

productsSum(selectedItems);

const productsOff = (selectedItems) => {
  let discountSum = 0;

  selectedItems.forEach((el) => {
    if (el.disc_ref_id) {
      discountSum += (el.price * el.disc_ref_id.disc_percent * el.quantity) / 100;
    } else {
      discountSum += (el.price * el.quantity) / 100;
    }
  }
);
  return Math.floor(discountSum);
};

productsOff(selectedItems);

const productsAfterOff = (selectedItems) => {
  try {
    let discountSum = 0;
    selectedItems.forEach((el) => {
      if (el.disc_ref_id) {
        discountSum += (el.price * (100 - el.disc_ref_id.disc_percent) * el.quantity) / 100;
      } else {
        discountSum += el.price * el.quantity;
      }
    });
    return Math.ceil(discountSum);
  } catch (error) {
    console.error("An error occurred:", error);
    return 0; // Xato bo'lgan taqdirda standart qiymat
  }
};

productsAfterOff(selectedItems);

const bonus = (selectedItems) => {
  try {
    let discountSum = 0;
    selectedItems.forEach((el) => {
      if (el.disc_ref_id) {
        discountSum += (el.price * (100 - el.disc_ref_id.disc_percent) * el.quantity) / 100;
      } else {
        discountSum += (el.price * el.quantity) / 100;
      }
    });
    return Math.floor(discountSum / 1000);
  } catch (error) {
    console.error("An error occurred:", error);
  }
};

bonus(selectedItems);

let buy_desc = document.querySelector("#buy-desc");

function getItemCostDesc() {
  return `
   <div class="item">
  <div class="seperate-border">
  <div
                    class="all-item d-flex justify-content-between align-items-center"
                  >
                    <p class="main-p m-0">${productCount(selectedItems)}
                    tovar</p>
                    <p class="main-p m-0">${productsSum(selectedItems)} SO'M</p>
                    </div>
                    <div
                    class="all-item d-flex justify-content-between align-items-center"
                    >
                    <p class="main-p m-0">Chegirma</p>
                    <p class="main-p off m-0">-${productsOff(
    selectedItems
  )} SO'M</p>
                    </div>
                    </div>
                    <div
                    class="all-item d-flex justify-content-between align-items-center mt-3"
                    >
                    <p class="main-p m-0">Jami</p>
                    <h3 class="little-h m-0">${productsAfterOff(
    selectedItems
  )} SO'M</h3>
                    </div>
                    <div
                    class="product-bonus d-flex justify-content-center align-items-center mt-2"
                    >
                    <img src="./image/bonus-icon.png" alt="" />
                    <p class="little-p m-0 ms-2 color-green">
                    Siz ${bonus(selectedItems)} bonus olasiz
                    </p>
                    </div>
                    <button id="order-btn" class="book-btn w-100 mt-4">Buyurtmani xarid qilish</button>
                    </div>
                    `;
}

buy_desc.innerHTML = getItemCostDesc();

const getOffCost = (discount, price, quantity) => `${Math.floor((price * quantity * (100 - discount.disc_percent)) / 100)}`;

const getProductCost = (price, quantity) => Math.floor(price * quantity);

const getCartProduct = (
  { pro_name, quantity, price, discount, link, _id }
) => {
  return `
    <div class="mt-3">
      <div class="card">
        <div class="d-flex flex-wrap">
          <div class="col-3 col-md-2 p-0 d-flex align-items-center">
            <img src=${link} class="card-img-top h-50 object-fit-scale" alt="..." />
          </div>
          <div class="col-9 col-md-5 p-1 ps-2 py-3">
            <div class="card-body p-0">
              <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title">${pro_name}</h5>
              </div>
              <div class="d-flex align-items-center">
                <p class="card-text">${price} SO'M <p class="little-p ms-2">har bir dona</p>
                  ${discount ? `<span class="product-discount">${discount.disc_percent} %</span>` : ''}
                </p>
              </div>
            </div>
          </div>
          <div class="res-view col-12 col-md-5 p-1 d-flex">
            <div class="count-product col-6 d-flex p-1 align-items-center">
              <button class="btn-left btn btn-primary" onclick="changeQuantity('-', '${_id}')"> - </button>
              <span>${quantity}</span>
              <button class="btn-right btn btn-primary" onclick="changeQuantity('+','${_id}')"> + </button>
            </div>
            <div class="col-6 p-1 d-flex flex-column justify-content-center">
              <div onclick="remove('${_id}')" class="cick">
                <i class="fa-solid fa-square-xmark" style="color: #ff5757;"></i>
              </div>
              ${discount ? `
                <p class="card-text huge-p text-end m-0">${getOffCost(discount, price, quantity)} SO‘M</p>
                <p class="card-text text-end m-0 deleteCost">${getProductCost(price, quantity)} SO‘M</p>
              ` : ""}
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
};

cart.forEach((el) => {
  cart_row.innerHTML += getCartProduct({
    pro_name: el.pro_name,
    price: el.price,
    quantity: el.quantity,
    discount: el.disc_ref_id,
    link: el.link,
    _id: el._id
  });
});


const changeQuantity = (status, _id) => {
  let product = cart.find((el) => el._id == _id);
  if (status == "-") {
    if (product.quantity == 1) {
      cart = cart.filter((el) => el._id != _id);
    }
  }
  cart = cart.map((el) => {
    if (el._id == _id) {
      status == "+" ? el.quantity++ : el.quantity--;
    }
    return el;
  });
  localStorage.setItem("cart", JSON.stringify(cart));
  window.location.reload();
};

const order_btn = document.getElementById("order-btn");
order_btn.onclick = async () => {
  let token = localStorage.getItem("token");
  if (token) {
    let orders = [];
    let products = JSON.parse(localStorage.getItem("cart"));
    products.forEach(pro => {
      orders.push(pro._id);
    })
    if (orders.length > 0) {
      let data = await fetch("/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          orders
        })
      });
      data = await data.json()
      if ([200, 201, 204].includes(data.status)) {
        localStorage.removeItem("cart");
        window.location.reload();
      }
    }
    else {
      window.confirm("Iltimos, buyurtma berishdan oldin biror narsani tanlang!")
    }
  }
  else {
    window.confirm("Iltimos, hisobingizga kiring!")
  }
}