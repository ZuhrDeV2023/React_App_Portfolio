(
    async function get() {
        let token = localStorage.getItem("token");
        if (token) {
            const orderRow = document.querySelector(".order-row");
            let data = await fetch('/orders');
            data = await data.json();

            [200, 201, 204].includes(data.status)
                ? (orderRow.innerHTML = data.data
                    .map((el) => {
                        const cdate = el.created_at.split("T");
                        const ddate = el.deleted_at?.split("T");

                        return `
            <div class='card ${el.deleted_at ? "o‘chirilgan" : ""} mb-2'>
              <h5 class="card-header py-3">Qabul: ${el.user_ref_id.username.toUpperCase()}, id: ${el.user_ref_id._id}</h5>
              <div class="card-body">
                <h5 class="card-title">Mahsulotlar: ${el.products.map((el) => el.pro_name).join(", ")}</h5>
                <p class="card-text">Qabul qilingan sana: ${cdate[0]}, ${cdate[1].split(".")[0]}</p>
                ${el.deleted_at ? ` <p class="card-text">Bekor qilingan sana: ${ddate[0]}, ${ddate[1].split(".")[0]}</p>` : `<button onclick="cecel('${el._id}')" class="btn btn-danger float-end">Buyurtmani bekor qilish</button>`}
              </div>
            </div>
          `;
                    })
                    .join("\n"))
                : window.alert("Iltimos, tizimga kiring va qayta urinib ko‘ring!");
        } else {
            window.alert("Iltimos, tizimga kiring va qayta urinib ko‘ring!");
            window.location.href = '/';
        }
    }
)()

const cancelOrder = async (id) => {
    let really = window.confirm("Bu buyurtmani oʻchirib tashlamoqchimisiz?");

    if (really) {
        let data = await fetch("/orders/" + id, {
            method: "DELETE",
        }
    );

        data = await data.json();

        [200, 201, 204, 203].includes(data.status)
            ? (window.alert("Buyurtma muvaffaqiyatli o‘chirildi"), window.location.reload())
            : null;
    }
};