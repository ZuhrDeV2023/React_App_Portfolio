const auto = async () => {
    let product_id = localStorage.getItem('product_id');
    const product_img = document.querySelector(".pro-img");
    if (product_id) {
        let data = await fetch(`/products/${product_id}`);
        data = await data.json();
        let { link } = data;
        product_img.src = link;
    }
};

auto();