(async function get() {
    try {
        let token = localStorage.getItem("token");
        if (token) {
            const userRow = document.querySelector(".user-row");
            let data = await fetch('/users');
            if (data.ok) {
                const userData = await data.json();
                for (const el of userData.data) {
                    userRow.innerHTML += `
            <div class="card position-relative w-50">
              ${el.pos_ref_id.pos_name === "admin" ? '<i class="fa-solid fa-star admin position-absolute" style="color: #ffdd00;"></i>' : ""} 
              <img src="${el.avatar}" class="card-img-top object-fit-scale" alt="...">
              <div class="card-body">
                <h5 class="card-title">Foydalanuvchi nomi: ${el.username}</h5>
                <p class="card-text">
                  Elektron pochta: ${el.email}
                </p>
                <p class="card-text">
                  Aloqa uchun telefon: ${el.contact}
                </p>
                <button onclick="setadmin('${el._id}')" class="btn ${el.pos_ref_id.pos_name === "admin" ? "btn-danger" : "btn-primary"} ">
                  ${el.pos_ref_id.pos_name === "admin" ? "Admin tomonidan bekor qilish" : "Admin sifatida tayinlang"}
                </button>
              </div>
            </div>`;
                }
            } else {
                window.alert("Foydalanuvchi maʼlumotlarini olib boʻlmadi.");
            }
        } else {
            window.alert("Iltimos, tizimga kiring va qayta urinib ko'ring!");
            window.location.href = '/';
        }
    } catch (error) {
        console.error(error);
    }
}
)();

async function setadmin(id) {
    try {
        let data = await fetch('/users/addadmin/' + id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
        });
        data.ok
            ? (await data.json(), window.alert("Muvaffaqiyatli o'zgartirildi!"), window.location.reload())
            : console.log((await data.json()).message);
    } catch (error) {
        console.error(error);
    }
}