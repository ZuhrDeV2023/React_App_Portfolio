(
  async function auto() {
    let token = localStorage.getItem("token");
    if (token) {
      const orderRow = document.querySelector(".order-row");
      let data = await fetch('/orders/me/' + token);
      data = await data.json();
      if ([200, 201, 204].includes(data.status)) {

        for (el of data.data) {
          let cdate = el.created_at.split("T")
          let ddate = el.deleted_at?.split("T")

          orderRow.innerHTML += `
              <div class='card ${el.deleted_at ? "o'chirildi" : ""}'>
                <h5 class="card-header py-3">Qabul qiluvchi: ${el.user_ref_id.username.toUpperCase()}</h5>
                  <div class="card-body">
                      <h5 class="card-title">Mahsulotlar: ${el.products.map(el => { return el.pro_name })}</h5 >
                      <p class="card-text">Qabul qilingan sana: ${cdate[0]}, ${cdate[1].split(".")[0]}</p> 
                      ${el.deleted_at ?
                      ` <p class="card-text">Bekor qilingan sana: ${ddate[0]}, ${ddate[1].split(".")[0]}</p>` : 
                      ` <button onclick="cencel('${el._id}')" class="btn btn-danger float-end">
                          Buyurtmani bekor qilish
                        </button>`}  
                  </div >
            </div >
          `
        }
      }
      else {
        window.alert("Iltimos, tizimga kiring va qayta urinib ko'ring!")
      }
    }
    else {
      window.alert("Iltimos, tizimga kiring va qayta urinib ko'ring!")
      window.location.href = '/'
    }
  }
  )()
  async function cencel(id) {
    let really = window.confirm("Bu buyurtmani oʻchirib tashlamoqchimisiz?");
    if (really) {
      let data = await fetch("/orders/" + id, {
        method: "DELETE",
      });
      data = await data.json();
      if ([200, 201, 204, 203].includes(data.status)) {
        window.alert("Buyurtma muvaffaqiyatli o'chirildi!");
        window.location.reload();
      }
    }
}