const btn = document.getElementById('send');

const handleRegister = async () => {
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const contact = document.getElementById('contact').value.trim();

    if (!email || !password || !contact || !username) return;

    try {
        const response = await fetch('/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(
                {
                    email,
                    username,
                    password,
                    contact,
                }
            ),
        }
    );

        const data = await response.json();

        if ([200, 201, 204, 203].includes(data.status)) {
            localStorage.setItem('token', data.token);
            location.href = '/';
        } else {
            const hint = document.getElementById('hint');
            hint.innerHTML = data.message;
        }
    } catch (error) {
        console.error('Xatolik yuz berdi:', error);
    }
};

btn.addEventListener('click', handleRegister);