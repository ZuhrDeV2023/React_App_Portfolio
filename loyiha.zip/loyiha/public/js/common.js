const cart_length = document.querySelector(".cart");
const cartLength = document.querySelector(".phoneCart");
const cart_local = localStorage.getItem("cart");
const cart_parse = JSON.parse(cart_local);
const favourite_parse = JSON.parse(localStorage.getItem("favourite"));

let cart = cart_parse || [];
let favourite = favourite_parse || [];

const setCart = () => {
  localStorage.setItem("cart", JSON.stringify(cart));
};

const setFavouriteCart = () => {
  localStorage.setItem("favourite", JSON.stringify(favourite));
};