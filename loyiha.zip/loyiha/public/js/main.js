const discount_row = document.querySelector("#discount_row");
const new_row = document.querySelector("#new_row");

(async function getProducts() {
  let products = await fetch("/products");
  products = await products.json();
  let count = 0;
  for (el of products) {
    if (el.disc_ref_id && count < 4) {
      discount_row.innerHTML += getCard(
        el.pro_name,
        el.brand_ref_id.brand_name,
        el.pro_desc,
        el.price,
        el.rating,
        el.disc_ref_id,
        el.link,
        el._id.toString(),
      );
      count++;
    }
  }
  count = 0;
  for (el of products) {
    count < 4
      ? (new_row.innerHTML += getCard(
        el.pro_name,
        el.brand_ref_id.brand_name,
        el.pro_desc,
        el.price,
        el.rating,
        el.disc_ref_id,
        el.link,
        el._id.toString()
      ),
        count++)
      : null;
  }
}
)()

const futures = [
  {
    heading: "LOGO kartasiga murojaat qiling",
    description: "Va do‘konlarda va veb-saytda xarid qilishda bonuslarga ega bo‘ling",
    image: "https://freesvg.org/img/basicCreditCard.png",
  },
  {
    heading: "Reklama mahsulotlarini sotib oling",
    description: "Va ikki baravar ko‘p bonuslarga ega bo‘ling",
    image: "https://cdn3d.iconscout.com/3d/premium/thumb/full-basket-2891365-2409775@0.png",
  },
];

const getFutureCard = (heading, description, image) => `
  <div class="future-card d-flex">
    <div class="future-card-desc ps-3 pt-3">
      <h2 class="little-h ">${heading}</h2>
      <p class="main-p m-0">
        ${description}
      </p>
    </div>
    <div class="future-card-img w-50 h-80">
     <img src="${image}" class="object-fit-scale w-50 h-80" alt="card-image" />
    </div>
  </div>
`;

let future_cards_row = document.querySelector(".future-card-row");
for (el of futures) {
  future_cards_row.innerHTML += getFutureCard(
    el.heading,
    el.description,
    el.image
  );
}

let tabs = document.querySelectorAll(".tabs-toogle");
let contents = document.querySelectorAll(".tabs__content");

tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => {
    contents.forEach((content) => {
      content.classList.remove("is-active");
    });
    tabs.forEach((tab) => {
      tab.classList.remove("is-active");
    });
    tabs[index].classList.add("is-active");

    contents[index].classList.add("is-active");
  });
}
);

const article = [
  {
    img: "https://www.gazeta.uz/media/img/2022/10/w0dMkv16672203878803_b.jpg",
    date: "30.08.2023",
    heading: "1-sentabrdan nimalar o‘zgaradi?",
    paragraph:
      `Talabalar uchun yangi turdagi stipendiya joriy etiladi, maktab direktorlariga qator huquqlar beriladi, “Yong‘indan ogohlik” umummilliy kampaniyasi o‘tkaziladi, ichki ishlar hodimlari fuqarolar bilan ishlash bo‘yicha o‘qitiladi, subsidiya endi onlayn ajratiladi — 1-sentabrdan nimalar o‘zgaradi?`,
  },
  {
    img: "https://www.gazeta.uz/media/img/2023/10/95alTe16978168336301_b.jpg",
    date: "05.05.2023",
    heading: "Kanada Hindistondan 41 diplomatni chaqirib oldi",
    paragraph:
      "Kanada Hindistondan 41 nafar diplomatini vataniga qaytardi, deb xabar bermoqda CNN. Avvalroq Hindiston rasmiylari ular oktabrdan keyin ham mamlakatda qolsa, diplomatik daxlsizliklari bekor qilinishi bilan tahdid qilgan edi.",
  },
  {
    img: "https://www.gazeta.uz/media/img/2020/04/cEhMZX15867749124016_b.jpg",
    date: "22.07.2023",
    heading: "O‘zbekistonda saytlarni buzish holatlari bo‘lganmi? Xavfsizlik bo‘yicha ekspert izohi",
    paragraph:
      "O‘zbekistonda qator saytlardan foydalanuvchi ma’lumotlari sizib chiqqani ma’lum bo‘ldi. Gap buzib kirish haqida emas, balki stilerlar — brauzerlardan autentifikatsiya ma’lumotlarini o‘g‘irlaydigan viruslarning eski bazasi haqida bormoqda.",
  },
];

const getArticleCard = (img, date, heading, paragraph) => `
  <div class="article-card">
    <div class="article-card-img">
      <img src="${img}" alt=".." />
    </div>
    <div class="article-card-desc p-2">
      <p class="little-p">${date}</p>
      <p class="huge-p">${heading}</p>
      <p class="main-p">${paragraph}</p>
      <button class="main-btn article-btn">Batafsil</button>
    </div>
  </div>
`;

let article_row = document.querySelector("#article_row");

article_row.innerHTML = article.map(el => getArticleCard(el.img, el.date, el.heading, el.paragraph)).join('');