import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();

export const SIGN = async (payload) => {
    return jwt.sign({ token: payload }, process.env.SECRET, { expiresIn: "24h" });
};

export const VERIFY = (token) => jwt.verify(token, process.env.SECRET);