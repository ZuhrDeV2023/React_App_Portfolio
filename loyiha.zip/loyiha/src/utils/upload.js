export const UPLOAD = (req, res) => {
    console.log(req.file, req.body);
}