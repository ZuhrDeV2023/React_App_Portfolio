
import { Schema, model } from "mongoose";

const brandSchema = new Schema(
    {
        brand_name: {
            type: String,
            required: [true, "Brend nomi yoqilgan bo‘lishi kerak!"]
        },
        logo: {
            type: String,
            required: [true, "Brend nomi yoqilgan bo‘lishi kerak!"]
        },
        products: {
            type: Array,
            ref: "products"
        }
    }
);

export const brand_schema = model('brands', brandSchema);