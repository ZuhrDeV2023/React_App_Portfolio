import { Schema, Types, model } from "mongoose";

const userSchema = new Schema(
    {
        username: {
            type: String,
            min: 5,
            max: 50,
            required: [true, 'Iltimos, foydalanuvchi nomini kiriting!']
        },

        email: {
            type: String,
            required: [true, 'Iltimos, elektron pochta manzilini kiriting!'],
            unique: true,
        },

        avatar: {
            type: String,
            default: "/image/user.png"
        },

        contact: {
            type: String,
            required: [true, 'Iltimos, kontaktni kiriting'],
        },

        password: {
            type: String,
            required: [true, 'Iltimos, parol kiriting'],
            min: 4
        },

        orders: {
            type: Array,
            ref: 'orders',
        },

        pos_ref_id: {
            type: Types.ObjectId,
            default: "64f8b8d559a352f22d1b6163",
            ref: "positions"
        },

        my_comments: {
            type: Array,
            ref: "comments"
        },

        deleted_at: {
            type: Date,
        }
    },
    {
        timestamps: {
            updatedAt: false,
            createdAt: "created_at"
        },

        strictPopulate: false,
    }
);

export const user_schema = model('users', userSchema);