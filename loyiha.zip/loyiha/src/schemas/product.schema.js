
import { Schema, Types, model } from "mongoose";

const productSchema = new Schema(
    {
        pro_name: {
            type: String,
            min: 3,
            max: 255,
            required: [true, "Mahsulot nomi yoqilgan bo'lishi kerak!"]
        },

        sub_ref_id: {
            type: Types.ObjectId,
            ref: "subcategories"
        },
        
        cat_ref_id: {
            type: Types.ObjectId,
            ref: "categories"
        },
        
        link: {
            type: String,
            default: "/image/product.png"
        },
        
        price: {
            type: Number,
            required: [true, "Mahsulot narxi yoqilgan bo'lishi kerak!"]
        },
        
        pro_desc: {
            type: String,
            max: 512,
            required: [true, "Mahsulot tavsifi yoqilgan bo'lishi kerak!"]
        },
        
        disc_ref_id: {
            type: Types.ObjectId,
            ref: "discounts"
        },
        
        rating: {
            type: Number,
            default: 5,
        },
        
        quantity: {
            type: Number,
            default: 1,
        },
        
        orders: {
            type: Number,
            default: 0,
        },
        
        brand_ref_id: {
            type: Types.ObjectId,
            ref: "brands",
            required: [true, "Mahsulot brendi yoqilgan bo'lishi kerak!"]
        },
        
        amount: {
            type: Number,
            required: [true, "Mahsulot miqdori yoqilgan bo'lishi kerak!"]
        },
        
        store_ref_id: {
            type: Types.ObjectId,
            ref: "users"
        },
        
        comments: {
            type: Array,
            ref: 'comments'
        }
    }
);

export const product_schema = model('products', productSchema);