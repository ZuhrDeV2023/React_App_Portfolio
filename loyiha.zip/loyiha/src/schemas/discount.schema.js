
import { Schema, model } from "mongoose";

const discountSchema = new Schema(
    {
        disc_name: {
            type: String,
            required: [true, "Chegirma nomi yoqilgan bo‘lishi kerak!"]
        },
        disc_percent: {
            type: Number,
            required: [true, "Chegirma foizi yoqilgan bo‘lishi kerak!"]
        },
        products: {
            type: Array,
            ref: "products"
        }
    }
);

export const discount_schema = model('discounts', discountSchema);