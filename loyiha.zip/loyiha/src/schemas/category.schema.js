
import { Schema, model } from "mongoose";

const categorySchema = new Schema(
    {
        cat_name: {
            type: String,
            min: 2,
            max: 50,
            required: [true, "Kategoriya nomi yoqilgan bo‘lishi kerak!"]
        },
        cat_img: {
            type: String,
            required: [true, "Category image yoqilgan bo‘lishi kerak!"]
        },
        subcategories: {
            type: Array,
            ref: "subcategories"
        },
        products: {
            type: Array,
            ref: "products"
        }
    }
);

export const category_schema = model('categories', categorySchema);