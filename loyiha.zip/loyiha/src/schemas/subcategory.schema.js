
import { Schema, Types, model } from "mongoose";

const subcategorySchema = new Schema(
    {
        cat_ref_id: {
            type: Types.ObjectId,
            ref: "categories"
        },
        sub_name: {
            type: String,
            min: 5,
            max: 60,
            required: [true, "Pastki toifa nomi yoqilgan bo'lishi kerak!"]
        },
        sub_img: {
            type: String,
            required: [true, "Subcategory img yoqilgan bo'lishi kerak!"]
        },
        products: {
            type: Array,
            ref: 'products'
        }
    }
);

export const subcategory_schema = model('subcategories', subcategorySchema);