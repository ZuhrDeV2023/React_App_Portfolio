import { discount_model } from "../models/discount.model.js";

class discount {
    async get(req, res) {
        try {
            const { id } = req.params;
            let result = await discount_model.select(id);
            if (typeof result == 'string') throw new Error(result);
           
            res.send(result)
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async post(req, res) {
        try {
            let result = await discount_model.create(req.body);
            if (typeof result == 'string') throw new Error(result);
            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async put(req, res) {
        try {
            const { id } = req.params;
            let result = await discount_model.update(id, req.body);
            if (typeof result == 'string') throw new Error(result);
            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async delete(req, res) {
        try {
            const { id } = req.params;
            let result = await discount_model.remove(id);
            if (typeof result == 'string') throw new Error(result);
            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }
}

export const discount_controller = new discount();