import { category_model } from "../models/category.model.js";

class category {
    async get(req, res) {
        try {
            const { id } = req.params;

            let result = await category_model.select(id, req.query);
            if (typeof result == 'string') throw new Error(result);
            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async post(req, res) {
        try {
            let result = await category_model.create(req.body);
            if (typeof result == 'string') throw new Error(result);

            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async put(req, res) {
        try {
            const { id } = req.params;
            let result = await category_model.update(id, req.body);
            if (typeof result == 'string') throw new Error(result);

            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }

    async delete(req, res) {
        try {
            const { id } = req.params;
            let result = await category_model.remove(id);
            if (typeof result == 'string') throw new Error(result);

            res.send(result);
        } catch (error) {
            res.send(
                {
                    status: 404,
                    message: error.message,
                    data: null
                }
            )
        }
    }
}

export const category_controller = new category();