import mongoose from "mongoose";
const url = "mongodb://127.0.0.1:27017/shop";

async function connectToDatabase() {
    try {
        await mongoose.connect(url, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log("Ulanish o'rnatildi!");
    } catch (error) {
        console.error(error.message);
    }
}

connectToDatabase();