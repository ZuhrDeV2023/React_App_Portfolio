import nodemailer from "nodemailer";

export const sendMail = (to, subject, password) => {
    const transporter = nodemailer.createTransport(
        {
            service: "gmail",
            auth: {
                user: "muhammadiyevj768@gmail.com",
                pass: "ccya gfjy ldbl iwff ",
            },
        }
    );

    const mailOptions = {
        from: "muhammadiyevj768@gmail.com",
        to,
        subject,
        html: `<b>Sizning parolingiz: ${password}<b>`,
    };
    return transporter.sendMail(mailOptions);
};